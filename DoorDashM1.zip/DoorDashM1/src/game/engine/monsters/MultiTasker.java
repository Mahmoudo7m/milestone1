package game.engine.monsters;

import game.engine.Role;
import game.engine.Constants;
public class MultiTasker extends Monster {
	private int normalSpeedTurns;
	
	public MultiTasker(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.normalSpeedTurns = 0;
	}

	public int getNormalSpeedTurns() {
		return normalSpeedTurns;
	}

	public void setNormalSpeedTurns(int normalSpeedTurns) {
		this.normalSpeedTurns = normalSpeedTurns;
	}
	public void executePowerupEffect(Monster opponentMonster) {
	    this.setNormalSpeedTurns(2);
	}

	public void setEnergy(int energy) {
	    int change = energy - getEnergy();
	    if (change != 0) {
	        super.setEnergy(getEnergy() + change + Constants.MULTITASKER_BONUS);
	    } else {
	        super.setEnergy(energy);
	    }
	}

}