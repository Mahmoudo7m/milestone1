package game.engine.monsters;

import game.engine.Role;

public class Dynamo extends Monster {
	
	public Dynamo(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
	}
	public void setEnergy(int energy) {
	    int change = energy - getEnergy();
	    super.setEnergy(getEnergy() + change * 2);
	}

	public void executePowerupEffect(Monster opponentMonster) {
	    opponentMonster.setFrozen(true);
	}
}
